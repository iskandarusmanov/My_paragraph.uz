import React from "react";
import { useRouter } from "next/router";

const categoryPage = () => {
  const router = useRouter();

  return <div>CategoryPage</div>;
};

export default categoryPage;
