import React from 'react'
import CategoryPage from '@/components/Catagories/Category';

export default function category() {

  return (
    <div>
      <CategoryPage />
    </div>
  )
}
