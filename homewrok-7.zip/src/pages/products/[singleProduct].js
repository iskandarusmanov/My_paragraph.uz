import SingleProduct from '@/components/Products/SingleProduct'
import React from 'react'

export default function singleProduct() {
  return (
    <div className='mt-[40px]'>
      <SingleProduct />
    </div>
  )
}
