import React from 'react'

export default function Footer() {
  return (
    <div className='w-fit m-auto p-24 font-bold text-[40px]'>Footer</div>
  )
}
